#include <iostream>
#include <type_traits>
#include <typeinfo>
#include <vector>
#include <tuple>
/*Discuss the difference between direct list initialisation and copy list initialisation in C++17/20 compared to C++11. 
std::vector<int> vec1 {5, 6, 7};  <- direct list init
std::vector<int> vec2 = {5, 6, 7}; <- copy list init

It seems like the behavior is generally the same. I was able to find on stack overflow (link below) some comments about how
there could be differences in behavior when you initialize using the auto keyword. 
The one part I found most interesting for me is if you initialize a single value using the auto keyword,
direct list init is able to give you back the proper type (say int), while copy list init gives you a type
called initializer_list<int>.  I remember seeing that a few times when I was coding and had to look it up. 
Seems for me it didn't make a difference with my baby programs. 

I think for readability I like the copy list init more because it is more explicit. When using direct list init, and especially
for a single value, it can look very much like a constructor. I imagine less seasoned coders could easily confuse () for {}.

https://stackoverflow.com/questions/50422129/differences-between-direct-list-initialization-and-copy-list-initialization


In which case does auto deduction reduce to std::initializer_list?  Give a code example
When you use auto and initialize one value using the direct list init style. 

Under which circumstances can we get ill-formed expressions?
template<typename T>
void test(T t) {}

test({1, 2}); <- this wouldn't work and the compiler wouldn't understand this as being an init list.


Discuss how Class Template Argument Deduction (CTAD)) reduces code verbosity. Give a non-trivial example using std::tuple and a user-defined class.
If you can use CTAD to cut down on having to explicit specify every template argument, I can already see it saving a lot of code for larger programs.
Even something like std::tuple tup(4, "hello", 2.5); as compared to std::tuple<int,string,double> tup = etc etc already saves a lot of code I think!
Investigate the applicability of decltype and std::is_same when comparing the type of a result with a �target� type.
*/
template<typename T1, typename T2, typename T3> 
class Test{
public:
    T1 t1;
    T2 t2;
    T3 t3;
    Test(T1, T2, T3) {
    }

std::tuple<T1,T2,T3>  TupMaker(T1 t1, T2 t2, T3 t3) {
        auto testTup(T1, T2, T3);
        return testTup;
    }
};


template <typename T>
void integerMapper() {
    if (std::is_signed<T>::value) {
        std::cout << std::boolalpha << "Is our input signed? " << std::is_signed<T>::value << std::endl;
        using makeUnsigned = typename std::make_unsigned<T>::type;
        std::cout << "Is it signed now ? " << std::is_signed<makeUnsigned>::value << std::endl;
    }
    else {
        std::cout << std::boolalpha << "Is our input signed? " << std::is_signed<T>::value << std::endl;
        using makeSigned = typename std::make_signed<T>::type;
        std::cout << "Is it signed now? " << std::is_signed<makeSigned>::value << std::endl;
    }
}

template <typename T>
void flipConst() {
    if (std::is_const_v<T>) {
        std::cout << std::boolalpha << "Is our input const? " << std::is_const_v<T> << std::endl;
        using makeNonConst = typename std::remove_const<T>::type;
        std::cout << "Is it const now ? " << std::is_const_v<makeNonConst> << std::endl;
    }
    else {
        std::cout << std::boolalpha << "Is our input const? " << std::is_const_v<T> << std::endl;
        using makeConst = typename std::add_const<T>::type;
        std::cout << "Is it const now? " << std::is_const_v<makeConst> << std::endl;
    }
    
}

template <typename T>
void flipVol() {
    if (std::is_volatile<T>::value) {
        std::cout << std::boolalpha << "Is our input volatile? " << std::is_volatile<T>::value << std::endl;
        using makeNonVol = typename std::remove_volatile<T>::type;
        std::cout << "Is it volatile now ? " << std::is_volatile<makeNonVol>::value << std::endl;
    }
    else {
        std::cout << std::boolalpha << "Is our input volatile? " << std::is_volatile<T>::value << std::endl;
        using makeVol = typename std::add_volatile<T>::type;
        std::cout << "Is it volatile now? " << std::is_const_v<makeVol> << std::endl;
    }

}

template <typename T>
void addRemovePtr() {
    //using DoublePointer = std::add_pointer <decltype(d)>::type;
    if (std::is_pointer<T>::value) {
        std::cout << std::boolalpha << "Is our input a pointer? " << std::is_pointer<T>::value << std::endl;
        using RemovePtr = typename std::remove_pointer<T>::type;
        std::cout << "How about now? " << std::is_pointer<RemovePtr>::value << std::endl;
    }
    else {
        std::cout << std::boolalpha << "Is our input a pointer? " << std::is_pointer<T>::value << std::endl;
        using addPtr = typename std::add_pointer<T>::type;
        std::cout << "Is it a pointer now? " << std::is_pointer<addPtr>::value << std::endl;
    }
    
}

int main() {
    
    // int <--> unsigned int
    std::cout << "First case - int" << std::endl; 
    integerMapper<int>(); //should come back unsigned int

    std::cout << "\nSecond case - unsigned int" << std::endl;
    integerMapper<unsigned int>(); //should come back int


    // ptr <--> not a ptr
    std::cout << "\nFirst case: int*" << std::endl;
    addRemovePtr<int*>();//should come back without pointer

    std::cout << "\nSecond case: double" << std::endl;
    addRemovePtr<double>(); //should come back with pointer


    //const <--> not a const
    std::cout << "\nFirst case - const" << std::endl; 
    flipConst<const int>(); //should come back just int

    std::cout << "\nSecond case - not const" << std::endl;
    flipConst<int>(); //should come back const int
    

    //volatile <--> not volatile
    std::cout << "\nFirst case - volatile" << std::endl;
    flipVol<volatile int>(); //should come back just int

    std::cout << "\nSecond case - not volatile" << std::endl;
    flipVol<int>(); //should come back volatile int
    
    //initializer list example
    auto vec1{5}; //< -direct list init
    auto vec2 = {5}; //< -copy list init

    std::cout << "\nvec1 type is: " << typeid(vec1).name() << std::endl;
    std::cout << "vec2 type is: "<< typeid(vec2).name() << std::endl;

    //CTAD goodness
    auto tup = std::make_tuple(4, "hello", 2.275); 
    auto tupNew = new Test{5, "bob", 5.875}; // allocated type should be int, string, double
    //auto TupMaker(tupNew->t1, tupNew->t2, tupNew->t3); 
    // The above doesn't compile. It picks up second arg as const char* instead of string which is what the function above requires. Interesting!

    std::cout << "\nType of first element of first tuple is: " << typeid(get<0>(tup)).name() << std::endl;
    std::cout << "Type of second element of first tuple is: " << typeid(get<1>(tup)).name() << std::endl;
    std::cout << "Type of third element of first tuple is: " << typeid(get<2>(tup)).name() << std::endl;
    

    std::cout << typeid(get<2>(tup)).name() << " " << typeid(tupNew->t3).name() << std::endl;
    //std::cout << "\nAre first elements of the tuples the same type: " << std::is_same<decltype(get<2>(tup)), decltype(tupNew->t3)>::value << std::endl; //I get false but expected true!

    std::cout << "\nAre 1st elements of the tuples the same type: " << (typeid(get<0>(tup)).name() == typeid(tupNew->t1).name()) << std::endl; //true
    std::cout << "\nAre 2nd elements of the tuples the same type: " << (typeid(get<1>(tup)).name() == typeid(tupNew->t2).name()) << std::endl; //true
    std::cout << "\nAre 3rd elements of the tuples the same type: " << (typeid(get<2>(tup)).name() == typeid(tupNew->t3).name()) << std::endl; //true
    

	return 0;
}