#include <iostream>

template <typename T>
const char* Classify(T t)
{
    switch (std::fpclassify(t))
    {
    case FP_INFINITE:  return "Inf";
    case FP_NAN: return "NaN";
    case FP_NORMAL:    return "normal";
    case FP_SUBNORMAL: return "subnormal";
    case FP_ZERO: return "zero";
    default:  return "unknown";
    }
}

int main() {
    //Test this function for the following values(in other words, determine the category)
    double val = std::numeric_limits<double>::max();
    std::cout << "2.0 * val: " << Classify(2.0 * val) << std::endl;  //if
    std::cout << "3.1415 + value: " << Classify(3.1415 + val) <<std::endl; //normal
    double val2 = std::numeric_limits<double>::min();// � 3.1415;
    std::cout << "val2 - 3.1415: " << Classify((val2 - 3.1415) / 2.0) << std::endl; //normal
    std::cout << "DBL_MIN / 2.0: " << Classify(DBL_MIN / 2.0) << std::endl; //subnormal

    //Apply the functions std::isfinite, std::isinf, std::isnan, std::isnormal to the following values:
    double factor = 2.0;
    double val3 = factor * std::numeric_limits<double>::max();
    //std::cout << val3 � val3; //val3 - val3 doesn't compile...get a red squiggle under the minus sign

    std::cout << std::boolalpha  << "\nIs sqrt(-1) finite: " << std::isfinite(std::sqrt(-1.0)) << std::endl; //false
    std::cout << "Is sqrt(-1) inf: " << std::isinf(std::sqrt(-1.0)) << std::endl; //false 
    std::cout << "Is sqrt(-1) nan: " << std::isnan(std::sqrt(-1.0)) << std::endl; //true
    std::cout << "Is sqrt(-1) normal: " << std::isnormal(std::sqrt(-1.0)) << std::endl; //false

    std::cout << "\nIs log(0.0) finite: " << std::isfinite(std::log(0.0)) << std::endl; //false
    std::cout << "Is log(0.0) inf: " << std::isinf(std::log(0.0)) << std::endl; //true 
    std::cout << "Is log(0.0) nan: " << std::isnan(std::log(0.0)) << std::endl; //false
    std::cout << "Is log(0.0) normal: " << std::isnormal(std::log(0.0)) << std::endl; //false
    
    std::cout << "\nIs val3 finite: " << std::isfinite(val3) << std::endl; //false
    std::cout << "Is val3 inf: " << std::isinf(val3) << std::endl; //true 
    std::cout << "Is val3 nan: " << std::isnan(val3) << std::endl; //false
    std::cout << "Is val3 normal: " << std::isnormal(val3) << std::endl; //false

	return 0;
}