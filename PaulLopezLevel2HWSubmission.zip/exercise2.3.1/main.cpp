#include <iostream>
#include <string>

int N = 5;
std::string S = "Global Hello";
//[[deprecated("old stuff")]] int N = 5;
//[[deprecated("old stuff")]] std::string S = "Global Hello";
//[[deprecated("old stuff")]] int N = 5;
//[[deprecated("old stuff")]]  std::string S = "Global Hello";

void Func()
//[[deprecated("old stuff")]] void Func()
{
	std::cout << "deprecated Func print"<< std::endl;
}

class Test{
//class [[deprecated("old stuff")]] Test {
public:
	int a;
	//[[deprecated("old stuff")]]  int a;
	Test() : a(0) { std::cout << "Default ctor" << std::endl; }
	Test(int n) : a(n) { std::cout << "Ctor with int" << std::endl; }
};
// enum [[deprecated("old stuff")]] { first, second = 0, third = first + 2 };
enum { first, second = 0, third = first + 2 };

enum class brand {
//enum class [[deprecated("old stuff")]]  brand {
		bmw, mercedes
};

struct Car {
	using enum brand; 
};

template <typename T>
void funcTemplate(T t) {
//void [[deprecated("old stuff")]] funcTemplate(T t) {
	std::cout << "This is a template Function with type: " << typeid(t).name() << std::endl;
}
//[[deprecated("old stuff")]] auto glambda = [](auto i) { return i * i; };
auto glambda = [](auto i) { return i*i; };

int main() {

	Func(); // doesn't compile when marked deprecated
	Test tst(5); //doesn't compile when marked deprecated
	std::cout << tst.a << std::endl; ////doesn't compile when marked deprecated or if member int a is marked deprecated.

	std::cout << "Global int: " << N << std::endl; //also not compiling when deprecated
	std::cout << "Global str: " << S << std::endl;//also not compiling when deprecated
	std::cout << first << " " << second << " " << third << std::endl; //enums also don't compile once marked deprecated

	Car car1;
	car1.bmw;
	car1.mercedes; //the above brands work only when not marked deprecated.

	int a{ 5 };
	funcTemplate(a);
	std::cout << "glambda output is: " << glambda(a) << std::endl; //also doesn't compile when marked deprecated.
	return 0;
}