#include <iostream>
#include <type_traits>
#include <memory>



template <typename T>
void IsPointer(const T& t) {
    if (std::is_pointer<T>::value) {
        std::cout << "This is a pointer type argument\n";
    }
    else {
        std::cout << "_not_ a pointer type argument\n";
    }
}
template <typename T>
auto IsNullPtr(const T& t) {
    if (std::is_null_pointer<T>::value) {
        std::cout << "This is a nullptr argument\n";
    }
    else {
        std::cout << "_not_ a nullptr argument\n";
    }
}
template <typename T>
void IsLRef(T& t) {
    if (std::is_lvalue_reference<T>::value) {
        std::cout << "This is a lvalue type argument\n";
    }
    else {
        std::cout << "_not_ a lvalue type argument\n";
    }
}

template <typename T>
void IsRRef(T&& t) {
    if (std::is_rvalue_reference<T>::value) {
        std::cout << "This is a rvalue type argument\n";
    }
    else {
        std::cout << "_not_ a rvalue type argument\n";
    }
}

template <typename T>
void IsMemberFn(T& t) {
    if (std::is_member_function_pointer<T>::value) {
        std::cout << "This is a member function pointer type argument\n";
    }
    else if (std::is_member_object_pointer<T>::value) {
        std::cout << "This a member function type argument\n";
    }
    else {
        std::cout << "_not_ a member function pointer type or pointer to a non-static member object to a argument\n";
    }
}

class Test {
public:
    int a;
   auto weirdFunc(const int&& b) {
        return b;
    }
   int TestFn(int a) { return a; }
};

void myFunc(int a) {
    //very boring function for pointer use
}



int main() {
    //a) Write a function to determine if a type is a pointer, null pointer, lvalue reference or rvalue reference.
    std::cout << "Part A: \n";
    std::cout << "Is Point Check: " << std::endl;
    const int* pt1 = new int(5);
    const int pt = 5;
    IsPointer(pt1);
    IsPointer(pt);
    std::cout << "\n";

    std::cout << "Is Nullptr Check: " << std::endl;
    auto pt2{ nullptr };
    IsNullPtr(pt2);
    IsNullPtr(pt);
    std::cout << "\n";

    std::cout << "Is lRef Check: " << std::endl;
    int num1 = 10;
    int& num1_ref = num1;
    int&& refLhs = 5;
    IsLRef(num1); //I would have thought this would return true
    IsLRef(refLhs); //this also I expected to be true. Both of these have int& type in the debugger.
   
    std::cout << "\n";

    std::cout << "Is rRef Check: " << std::endl;
    const int num2 = 10;
    const int& num2_ref = num2;
    const int&& refRhs = 5;

    IsRRef(refRhs); //compiles and becomes int& instead of int&&.
    IsRRef(5); //I expected this to return true since type is int&& in debugger mode.
    std::cout << "\n";

    //b) Determine if a type is a member function pointer or if it is a pointer to a non-static member object
    std::cout << "\nPartB: \n";
    Test tst{5};

   //funcPtr attempt 1
   void (*funcPtr)(int);
   funcPtr = &myFunc;

   //funcPtr attempt 2
   int (Test::* funcPtr2) (int) = &Test::TestFn;

   IsMemberFn(funcPtr);//feeding function a pointer to a function I hope!
   IsMemberFn(funcPtr2);//Got this one to work.


   //c) Is a shared pointer a pointer type ? Is it a pointer type when converted to a raw pointer
   std::cout << "\n\nPart C: \n";
   std::shared_ptr<int> sharedPtr = std::make_shared<int>(1);
   int* rawPtr(nullptr);
   rawPtr = new int(*sharedPtr);

   //rawPtr = sharedPtr;
   IsPointer(sharedPtr); //checking if shared ptr is a pointer type. Function returns false!
   IsPointer(rawPtr);

   

return 0;
}

