#include <boost/dynamic_bitset.hpp>
#include <bitset>
#include <iostream>
template<typename T>
boost::dynamic_bitset<T> toggleEvery(boost::dynamic_bitset<T>& dbs) {
	for (int i = 0; i < dbs.size(); i++) {
		if (dbs[i] == 0) {
			dbs[i] = 1;
		}
		else {
			dbs[i] = 0;
		}
	}
	return dbs;
}
int main() {
	const int N = 5;
	const int NNew = 10;
	boost::dynamic_bitset<unsigned long> dbs1(N);
	boost::dynamic_bitset<unsigned long> dbs2(N);
	std::cout << "dbs1: " << dbs1 << std::endl; //5 zeroes
	
	boost::dynamic_bitset<unsigned long> dbs3(N); 
	boost::dynamic_bitset<unsigned long> dbs4(N); 
	dbs3[1] = dbs4[1] = dbs3[2] = dbs4[2] = dbs3[3] = dbs4[3] = 1;
	std::cout << "dbs3: " << dbs4 << ", dbs3: " << dbs4 << std::endl; //both will show 01110
	
	std::cout << std::boolalpha << "Are dbs3 and dbs4 equal?" << (dbs3 == dbs4) << std::endl; //evaluates to true
	std::cout << "Are dbs1 and dbs3 equal?" << (dbs2 == dbs3) << std::endl; //evaluates to false

	boost::dynamic_bitset<unsigned  long> dbs5(N);; // we start with zeroes
	std::cout << "\nWe start with zeroes: " << dbs5 << std::endl;
	dbs5.set(); //set everything to 1
	std::cout << "We now have all ones: " << dbs5 << std::endl;
	dbs5.reset(); //set everything to 0
	std::cout << "We now have all zeroes again: " << dbs5 << std::endl;
	dbs5.flip(0); //flip index number 0
	dbs5.flip(2); //flip index number 2
	std::cout << "We now have a 1 in index 2: " << dbs5 << std::endl; //00101
	
	int countBit{};
	for (int i = 0; i < N; i++) {
		countBit += dbs5[i];
	}
	std::cout << "Number of set bits in bs4: " << countBit << std::endl;

	boost::dynamic_bitset<unsigned long> dbs6(N,25);
	std::cout << "convert to ulong: " << dbs6.to_ulong() << std::endl;
	
	try {
		boost::dynamic_bitset<unsigned long> dbs7(N,10); //invalid arguments gives me invalid bitset char error below
		//dbs7[8] = 1; //freaks out when I uncomment this. I can't even catch it...it just called abort() it says.
		std::cout << "dbs7: " << dbs7 << std::endl;
	}
	catch (std::exception& e) {
		std::cout << "Error is: " << e.what() << std::endl;
	}
	catch (...) {
		std::cout << "Boost unhandled exception!" << std::endl;
	}
	
	dbs1[1] = dbs2[1] = dbs1[3] = dbs2[3] = 1; //set some bits for fun
	std::cout << "dbs1 is: " << dbs1 << ", and dbs2 is: " << dbs2 << std::endl; //before toggle every function call
	//toggle both bitsets with a wee function call
	dbs1 = toggleEvery(dbs1);
	dbs2 = toggleEvery(dbs2);
	//after toggle
	std::cout << "dbs1[1] is: " << dbs1 << ", and dbs2[1] is: " << dbs2 << std::endl;
	
	std::cout << "dbs1[1] & dbs2[1]: " << (dbs1[1] & dbs2[1]) << std::endl;
	std::cout << "dbs1[1] | dbs2[1]: " << (dbs1[1] | dbs2[1]) << std::endl;
	std::cout << "dbs1[1] ^ dbs2[1]: " << (dbs1[1] ^ dbs2[1]) << std::endl;

	//right and left operations on bs1 and bs2
	//left operation on dbs1 by 2
	std::cout << "dbs1 value is currently: " << dbs1 << std::endl;
	dbs1 = dbs1 << 2;
	std::cout << "dbs1 value is now: " << dbs1 << std::endl;


	//Apply resize(), clear(), push_back(), pop_back() and append() to bitset instances.
	dbs1.resize(NNew);
	std::cout << "dbs1 value with NNew: " << dbs1 << std::endl;  //grows to 10
	dbs1.clear();
	std::cout << "dbs1 value after clear: " << dbs1 << std::endl;
	dbs1.push_back(1);
	dbs1.push_back(1);
	dbs1.push_back(1);
	dbs1.push_back(1);
	dbs1.push_back(1);
	dbs1.push_back(1);
	dbs1.push_back(1);
	std::cout << "dbs1 value after seven push_backs: " << dbs1 << std::endl;
	dbs1.pop_back();
	std::cout << "dbs1 value after a pop_back: " << dbs1 << std::endl;

	dbs1.append(111011);
	std::cout << "dbs1 value after a 110 append: " << dbs1 << std::endl;
	//test if a bitset is a subset (or proper subset) of another bitset
	dbs2.resize(NNew);
	dbs2.append(0);
	dbs2.pop_back();
	dbs2.pop_back();
	dbs2.pop_back();
	dbs2.pop_back();
	std::cout << "dbs2: " << dbs2 << std::endl;
	std::cout << "is dbs2 a subset of dbs1: " << std::boolalpha << ((dbs1 & dbs2) == dbs2) << std::endl; //check if dbs2 is part of dbs1

	std::cout << "find_first(): " << dbs1.find_first() << std::endl;
	std::cout<< "find_next(5): " << dbs1.find_next(5) << std::endl;


	return 0;

}