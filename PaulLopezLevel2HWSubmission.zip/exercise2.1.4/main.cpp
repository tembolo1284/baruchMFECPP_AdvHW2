#include <iostream>
#include <type_traits>
#include <memory>

class Shape {
public:
    virtual void draw() = 0;
};

class Base {
private:
    int y;
public:
    Base() {}
    void draw() {}
};

class Point: public Shape {
public:
    Point() {}
    //uncomment below two lines for exercise 4 part d)
    Point(Point& pt) = delete;
    Point& operator = (const Point& source) = delete;

    //below two lines for part e)
    Point(Point&& pt);
    Point& operator = (Point&& rhs);
    
    virtual void draw() override {}
};


int main() {
  

   std::cout << "\n\nExercise 4: \n";

   //a) Programmatically determine if type Point has a virtual destructor.
   std::cout << std::boolalpha;
   std::cout << "Does Point have a virtual destructor: " << std::has_virtual_destructor<Point>::value << std::endl;

   //b) Programmatically determine if type Point has the following constructors : default, copy, move.
   std::cout << "\nDoes Point have a default ctor: " << std::is_constructible<Point>::value << std::endl;
   std::cout << "Does Point have a copy ctor: " << std::is_copy_constructible<Point>::value << std::endl;
   std::cout << "Does Point have a move ctor: " << std::is_move_constructible<Point>::value << std::endl;

   //c) Programmatically determine if type Point is copy assignable / move assignable.
   std::cout << "\nIs Point copy assignable: " << std::is_copy_assignable<Point>::value << std::endl;
   std::cout << "Is Point move assignable: " << std::is_move_assignable<Point>::value << std::endl;

   //d) Set the copy constructor and assignment operator as �deleted functions�and perform steps b) - c) again; do you get the same result ?
   //copy and move ctors became false, and the copy and move assignability turned false as well.

   std::cout << "\nDoes Point have a default ctor: " << std::is_constructible<Point>::value << std::endl;
   std::cout << "Does Point have a copy ctor: " << std::is_copy_constructible<Point>::value << std::endl;
   std::cout << "Does Point have a move ctor: " << std::is_move_constructible<Point>::value << std::endl;

   std::cout << "\nIs Point copy assignable: " << std::is_copy_assignable<Point>::value << std::endl;
   std::cout << "Is Point move assignable: " << std::is_move_assignable<Point>::value << std::endl;

   //e) Add move semantics code(explicit move constructor and move assignment operator) and perform steps b) - c) again; do you get the same result ?
   //move ctor and assignability turned true now
   std::cout << "\nDoes Point have a default ctor: " << std::is_constructible<Point>::value << std::endl;
   std::cout << "Does Point have a copy ctor: " << std::is_copy_constructible<Point>::value << std::endl;
   std::cout << "Does Point have a move ctor: " << std::is_move_constructible<Point>::value << std::endl;

   std::cout << "\nIs Point copy assignable: " << std::is_copy_assignable<Point>::value << std::endl;
   std::cout << "Is Point move assignable: " << std::is_move_assignable<Point>::value << std::endl;



return 0;
}

