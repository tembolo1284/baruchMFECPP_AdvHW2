#include <iostream>
#include <vector>
#include <array>
#include <functional>


int main() {
    int size = 4; double val = 2.71;
    std::vector<double> data(size,val);

    std::cout << "data vector before fun() call: ";
    for (std::size_t i = 0; i < data.size(); ++i) { 
       std::cout << data[i] << " ";
    }
    std::cout << std::endl;
    // Default capture mode (not preferred)
    auto fun = [data = move(data)]() mutable {
        for (std::size_t i = 0; i < data.size(); ++i) {
            data[i] = 3.14; std::cout << data[i] << " ";
        }
        std::cout << '\n';
    };

    fun();

    // 'data' still exists and has been modified
    for (std::size_t i = 0; i < data.size(); ++i) { //data.size() == 0 after it gets nuked above so this never runs.
        data[i] = 3.14; std::cout << data[i] << ":";
    }

    // C++14 init capture with local variables
    int x = 1'000'000; // This is a digit separator
    auto fun4 = [&r = x]()
    {
        r *= 2;
        std::cout << "\nr: " << r;
    };
    fun4();
    std::cout << "\n\n";

    // Emulating generalized lambda capture with C++11
    //migrated to C++ 14 hopefully
    int size2 = 3; 
    double val2 = 1.41;
    std::vector<double> data2(size2, val2);
    std::array<double, 3> data3 = { 1.2, 2.4, 4.7 };
    //auto fun3 = std::bind([](std::vector<double>& array, //old code
       // std::array<double, 3> array2) {

    auto fun3 = [data3 = std::move(data3), data2 = std::move(data2)]() mutable { //<-- a little movey movey action.
            for (std::size_t i = 0; i < data2.size(); ++i) {
                data2[i] = 3.14; std::cout << data2[i] << "/";
            }
            std::cout << '\n';
            for (std::size_t i = 0; i < data3.size(); ++i) {
                data3[i] = 2.71; std::cout << data3[i] << "/";
            }

    };  // , std::move(data2), std::move(data3)); //commented out old code

    fun3();

    if (0 == data2.size() || 0 == data3.size()) {  //both array and vector get nuked after above lambda function runs. This gives me 0 after above runs.
        std::cout << "\nDouble arrays have no elements, OK\n";
    }
    else {
        std::cout << "\n Ouch!\n";
        for (std::size_t i = 0; i < data2.size(); ++i) {
            std::cout << data2[i] << "^";
        }
        for (std::size_t i = 0; i < data3.size(); ++i){
            std::cout << data3[i] << "^";
        }
    }

}