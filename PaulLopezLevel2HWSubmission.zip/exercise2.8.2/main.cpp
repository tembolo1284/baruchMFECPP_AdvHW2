/*j) Can you think of examples/applications where bytes and bitsets can be used, for example raw memory access and savings and performance improvements?*/
//beyond someone needing to use bits directly for their application/use, I think it would be very efficient to use a bitset to store
//conditions of true/false for a bunch of conditions you have to check. I think it would be better for mem savings than having a giant
//vector or array storing the true/false or 0/1 values.

#include <iostream>
#include <bitset>
#include <boost/dynamic_bitset.hpp>
#include <cstddef>

std::bitset<10> toggleEvery(std::bitset<10>& bs) {
	
	for (int i = 0; i < 10; i++) {
		if (bs[i] == 0) {
			bs[i] = 1;
		}
		else {
			bs[i] = 0;
		}
	}
	return bs;
}

int main() {
	const int N = 10;
	std::bitset<N> bs1(std::string("0110011001"));
	std::bitset<N> bs2(std::string("1111100110"));

	std::cout << "bs1 is: " << bs1 << ", bs2 is: " << bs2 << std::endl;

	//toggle both bitsets with a wee function call
	bs1 = toggleEvery(bs1);
	bs2 = toggleEvery(bs2);
	//after toggle
	std::cout << "bs1 is: " << bs1 << ", and bs2 is: " << bs2 << std::endl;

	std::cout << "bs1 & bs2: " << (bs1 & bs2) << std::endl;
	std::cout << "bs1 | bs2: " << (bs1 | bs2) << std::endl;
	std::cout << "bs1 ^ bs2: " << (bs1 ^ bs2) << std::endl;

	//right and left operations on bs1 and bs2
	//left operation on bs1 by 2
	std::cout << "bs1 value is currently: " << bs1 << std::endl;
	bs1 = bs1 << 2;
	std::cout << "bs1 value is now: " << bs1 << std::endl;

	//right operation on bss by 2
	std::cout << "\nbs2 value is currently: " << bs2 << std::endl;
	bs2 = bs2 >> 2;
	std::cout << "bs2 value is now: " << bs2 << std::endl;

	//hashing magic
	std::size_t bs1Hash = std::hash<std::bitset<N>>{}(bs1);
	std::size_t bs2Hash = std::hash<std::bitset<N>>{}(bs2);

	std::cout << "hash(bs1) = " << bs1Hash << std::endl;
	std::cout << "hash(bs2) = " << bs2Hash << std::endl;

	int blit = 0b0011;

	std::byte by1{ 0b0011 }; //  binary literal
	std::byte by2{45};
	std::byte by3 = by1 & by2; //AND
	std::byte by4 = by1 | by2; //OR

	std::bitset<4> bs(blit);
	std::cout << "bitset: " << bs << '\n';

	boost::dynamic_bitset<unsigned int> dbs(4); // all 0 by default
	dbs[1] = dbs[0] = 1;
	std::cout << "dynamic bitset: " << dbs << '\n';

	std::cout << "\nbyte by1: " << std::to_integer<int>(by1);
	std::cout << "\nbyte by2: " << std::to_integer<int>(by2);
	std::cout << "\nbyte by3: " << std::to_integer<int>(by3);
	std::cout << "\nbyte by4: " << std::to_integer<int>(by4) << std::endl;

	//left and right operations on bytes, including extreme case where shift is more that bits allocated
	std::cout << "\nby1 value: " << std::to_integer<int>(by1) << std::endl;
	by1 = by1 << 2; //left shift
	std::cout << "by1 value: " << std::to_integer<int>(by1) << std::endl;

	std::cout << "by2 value: " << std::to_integer<int>(by2) << std::endl;
	by2 = by2 >> 2; //right shift
	std::cout << "by2 value: " << std::to_integer<int>(by2) << std::endl;

	//extreme shifts
	by1 = by1 << 15; //left shift
	std::cout << "by1 value after 15 shifts left: " << std::to_integer<int>(by1) << std::endl;

	std::byte by5 = by1 >> 15; //right shift
	std::cout << "by5 value after 15 shifts right: " << std::to_integer<int>(by5) << std::endl;  //both 'extreme' shifts gave me 0.



	return 0;
}