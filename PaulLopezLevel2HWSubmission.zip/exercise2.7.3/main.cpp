/*a) Create error condition instances based on the following POSIX error codes(use scoped enumerator std::errc) :
	io_error.
	network_unreachable.
	no_such_file_or_directory.
	not_a_socket.
	permission_denied.
	b) Create an std::error_condition object based on the value 128 and the generic error category.

	c) Use std::make_error_condition(with std::io_errc as argument) to create an instance of std::error_condition.*/
#include <system_error>
#include <iostream>
#include <ios>

int main() {
auto err1 = std::make_error_condition(std::errc::io_error);
std::cout << "Error message: " << err1.message() << std::endl;

auto err2 = std::make_error_condition(std::errc::network_unreachable);
std::cout << "Error message: " << err2.message() << std::endl;

auto err3 = std::make_error_condition(std::errc::no_such_file_or_directory);
std::cout << "Error message: " << err3.message() << std::endl;

auto err4 = std::make_error_condition(std::errc::not_a_socket);
std::cout << "Error message: " << err4.message() << std::endl;

auto err5 = std::make_error_condition(std::errc::permission_denied);
std::cout << "Error message: " << err5.message() << std::endl;

std::error_condition error(128, std::generic_category());
std::cout << "Error value and category: " << error.value() << ", " << error.category().name() << std::endl; //for value 128 and generic_category()

std::error_condition err6 = std::make_error_condition(std::io_errc::stream);
std::cout << "Error message, value, and category name: " << err6.message() << ", " << err6.value() << ", " << err6.category().name() << std::endl;

	return 0;
}