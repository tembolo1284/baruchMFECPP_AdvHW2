#include <iostream>
#include <bitset>
#include <vector>

std::vector<bool> intersectionVec(std::vector<bool> vec1, std::vector<bool> vec2) {
	std::vector<bool> intVec;
	for (int i = 0; i < vec1.size(); i++) {
		if (vec1[i] == vec2[i]) {
			intVec.push_back(1); //if 11 or 00 then intersection == 1
		}
		else {
			intVec.push_back(0); //if 10 or 01 then intersection == 0
		}
	}
	return intVec;
}

int main() {
	const int N = 10;
	std::bitset<N> bs1(std::string("0101010101"));
	std::bitset<N> bs2(std::string("0111110000"));
	
	std::vector<bool> v1;
	std::vector<bool> v2;
	std::vector<bool> vec1;
	std::vector<bool> vec2;
	for (int i = 0; i < bs1.size(); i++) {
		vec1.push_back(bs1[i]);
		vec2.push_back(bs2[i]);
		v1.push_back(bs1[i]);
		v2.push_back(bs2[i]);
	}
	std::cout << "vec1: ";
	for (int i = 0 ; i < vec1.size(); i++) {
		std::cout << vec1[i];
	}
	std::cout << "\nvec2: ";
	for (int i = 0; i < vec2.size(); i++) {
		std::cout << vec2[i];
	}
	std::vector<bool> intVec = intersectionVec(vec1, vec2);

	std::cout << "\nIntersection: "; 
	for (int i = 0; i < vec2.size(); i++) {
		std::cout << intVec[i];
	}

	//and or and xor test on vectors.  Has to be done element by element in a loop
	std::vector<bool> andVec;
	std::vector<bool> orVec;
	std::vector<bool> xorVec;

	for (int i = 0; i < v1.size(); i++) {
		andVec.push_back(vec1[i] & vec2[i]);
		orVec.push_back(vec1[i] | vec2[i]);
		xorVec.push_back(vec1[i] ^ vec2[i]);
	}
	//std::cout << "vec1 & vec2: " << (vec1 & vec2) << '\n'; //doesn't compile unlike bitsets
	//std::cout << "vec1 | vec2: " << (vec1 | vec2) << '\n';//doesn't compile
	//std::cout << "vec1 ^ vec2: " << (vec1 ^ vec2) << '\n';//doesn't compile
	

	std::cout << "\nandVec: ";
	for (int i = 0; i < andVec.size(); i++) {
		std::cout << andVec[i];
	}

	std::cout << "\norVec: ";
	for (int i = 0; i < orVec.size(); i++) {
		std::cout << orVec[i];
	}
	std::cout << "\nxorVec: ";
	for (int i = 0; i < xorVec.size(); i++) {
		std::cout << xorVec[i];
	}

	//vectors are brutal to deal with compared to bitsets haha


	return 0;
}