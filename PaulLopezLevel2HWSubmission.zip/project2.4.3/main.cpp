#include <iostream>


int main() {
	using std::auto_ptr;
	using std::unique_ptr;
	// Define auto_ptr pointers instead of raw pointers
	std::auto_ptr <double> d(new double(1.0));
	std::auto_ptr <double> up(new double(2.5));

	// Dereference
	*d = 2.0;
	*up = 5.5;

	// Change ownership of auto_ptr
	// (after assignment, d is undefined)
	auto_ptr <double> d2 = d;
	//std::unique_ptr <double> up2 = up; //this doesn't compile
	std::unique_ptr <double> up2 = move(up); //this works though
	*d2 = 3.0;
	*up2 = 7.75;

	//the below breaks because d is now a nullptr and I can't deref it to print its value. Read access violation error
	//std::cout << "Auto values: " << *d.get() << ", " << *d2.get(); 
	
	std::cout << "Unique ptr values: " << *up2.get(); //this works fine. If I try to do *up.get() I get the same read access violation error.

}