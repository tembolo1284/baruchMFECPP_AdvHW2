#include <array>
#include <iostream>
#include <type_traits>
#include <vector>
#include <iterator>
#include <algorithm>

class Test {};

int main() {
	
        std::cout << std::boolalpha;
        std::cout << std::is_array<Test>::value << std::endl; //false
        std::cout << std::is_array<Test[]>::value << std::endl; //true
        std::cout << std::is_array<Test[3]>::value << std::endl; //true 
        std::cout << std::is_array<std::vector<double>>::value << std::endl; //false
        std::cout << std::is_array<std::array<double,5>>::value << std::endl; //false
        std::cout << std::is_array<double>::value << std::endl; //false 
        std::cout << std::is_array<int>::value << std::endl; //false 
        std::cout << std::is_array<int[]>::value << std::endl; //true 
        std::cout << std::is_array<int[3]>::value << std::endl; //true 
        std::cout << std::is_array<std::array<int, 3>>::value << std::endl; //false 


        std::cout << "\n-------------------Part B----------------\n";

        std::cout << std::rank<int[][3][4][5]>{} << std::endl; //rank = 4
        std::cout << std::extent<int[][3][4][5], 0>::value << std::endl; //0
        std::cout << std::extent<int[][3][4][5], 1>::value << std::endl; //3
        std::cout << std::extent<int[][3][4][5], 2>::value << std::endl; //4
        std::cout << std::extent<int[][3][4][5], 3>::value << std::endl; //5


        std::cout << "\n-------------------Part C----------------\n";
        
        //int arr[][3][4][5] = {0};
        typedef std::remove_extent<int>::type A;       // int
        typedef std::remove_extent<int[][3][4][5]>::type B;    

       //I'm stripping the first dimension of size 3 and getting the type (int in this case) when running remove_extent on the int[][3][4][5] array.
        
        std::cout << "typedefs of int:" << std::endl;
        std::cout << "A: " << std::is_same<int, A>::value << std::endl;
        std::cout << "B: " << std::is_same<int, B>::value << std::endl;

        typedef std::remove_all_extents<int>::type C;                // int
        typedef std::remove_all_extents<int[][3][4][5]>::type D;            

        std::cout << "C: " << std::is_same<int, C>::value << std::endl;
        std::cout << "D: " << std::is_same<int, D>::value << std::endl;
        //likewise when running remove_all_extents but now I get the type for every dimension of the array
       


	return 0;
}