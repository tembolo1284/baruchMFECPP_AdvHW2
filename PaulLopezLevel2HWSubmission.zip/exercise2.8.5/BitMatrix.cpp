#ifndef BitMatrix_CPP
#define BitMatrix_CPP
#include <bitset>
#include <iostream>
#include <string>
#include <sstream>
#include "BitMatrix.hpp"

template <std::size_t N, std::size_t M>
BitMatrix<N, M>::BitMatrix() { 
    for (std::bitset<M>& bs : m_bitArray) {
        bs = std::bitset<M>();
    }
    std::cout << "Default ctor" << std::endl; 
}

template <std::size_t N, std::size_t M>
BitMatrix<N, M>::BitMatrix(unsigned long val) { 
    for (std::bitset<M>& bs : m_bitArray) {
        bs = std::bitset<M>(val);
    }
    std::cout << "ctor with value" << std::endl; 
}

template <std::size_t N, std::size_t M>
void BitMatrix<N, M>::ToString() const {
    std::cout << "---------------" <<std::endl;
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            std::cout << m_bitArray[i][j] << ", "; //loop through the sucker freeze row and go over columns. Should be a 
        }
        std::cout << std::endl; //break line for next row
    }
    std::cout << "---------------" << std::endl;
}

template <std::size_t N, std::size_t M>
void BitMatrix<N, M>::Set() {
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            m_bitArray[i][j] = 1;
        }
    }
}

template <std::size_t N, std::size_t M>
void BitMatrix<N, M>::Reset() {
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            m_bitArray[i][j] = 0;
        }
    }
}

template <std::size_t N, std::size_t M>
void BitMatrix<N, M>::FlipBit(int a, int b) {
    if (a >= N || a < 0 || b < 0 || b >= M) {
        std::cout << "Sorry, indices entered are out of bounds." << std::endl;
    } 
    else if (m_bitArray[a][b] == 1) {
        m_bitArray[a][b] = 0;
    }
    else {
        m_bitArray[a][b] = 1;
    }
}
template <std::size_t N, std::size_t M>
int BitMatrix<N, M>::CountBits() {
    int count{};
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            if (m_bitArray[i][j] == 1) {
                count++;
            }
        }
    }
    return count;
}
        

template <std::size_t N, std::size_t M>
BitMatrix<N, M>::~BitMatrix() { 
    std::cout << "\ndestructor\n"; 
}

template<std::size_t N, std::size_t M>
bool BitMatrix<N, M>::at(unsigned int i, unsigned int j) {
    return m_bitArray[i][j];
}

template<std::size_t N, std::size_t M>
BitMatrix<N, M> BitMatrix<N, M>::ORFunc(BitMatrix<N, M> bm1) {
    BitMatrix<N, M> result;
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            result.m_bitArray[i][j] = bm1.at(i, j) | m_bitArray[i][j];
        }
    }
    return result;
}

template<std::size_t N, std::size_t M>
BitMatrix<N, M> BitMatrix<N, M>::ANDFunc(BitMatrix<N, M> bm1) {
    BitMatrix<N, M> result;
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            result.m_bitArray[i][j] = bm1.at(i,j) & m_bitArray[i][j]; //check each element of bm1 and m_bitArray
        }
    }
    return result;
}

template<std::size_t N, std::size_t M>
BitMatrix<N, M> BitMatrix<N, M>::XORFunc(BitMatrix<N, M> bm1) {
    BitMatrix<N, M> result;
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            result.m_bitArray[i][j] = bm1.at(i,j) ^ m_bitArray[i][j];
        }
    }
    return result;
}


#endif