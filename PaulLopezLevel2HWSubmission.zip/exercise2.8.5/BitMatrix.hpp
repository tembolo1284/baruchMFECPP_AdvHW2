#ifndef BitMatrix_HPP
#define BitMatrix_HPP
#include <bitset>
#include <array>
#include <string>
template <std::size_t N, std::size_t M>
class BitMatrix {
public:
    //std::bitset<N*M> m_bitset; //alternative possible data structure
    std::array<std::bitset<M>, N> m_bitArray; 

    BitMatrix();
    BitMatrix(unsigned long val);
    ~BitMatrix();
     
    bool at(unsigned int i, unsigned int j);
    
    void ToString() const; //returns cout string description of the matrix
    void Set(); //sets matrix to all ones
    void Reset(); //sets matrix to all zeroes
    void FlipBit(int i, int j); //sets bit at (i,j) to 0 or 1
    int CountBits(); //counts how many ones in matrix

    BitMatrix<N, M> ORFunc(BitMatrix<N, M> bm1);
    BitMatrix<N, M> ANDFunc(BitMatrix<N, M> bm1);
    BitMatrix<N, M> XORFunc(BitMatrix<N, M> bm1);
};

#ifndef BitMatrix_cpp // Must be the same name as in source file #define
#include "BitMatrix.cpp"
#endif

#endif