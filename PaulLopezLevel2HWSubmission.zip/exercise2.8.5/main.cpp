#include <iostream>
#include <bitset>
#include <sstream>
#include <string>
#include "BitMatrix.hpp"
int main() {
	const int N = 3;
	const int M = 5;
	BitMatrix<N, M> bm1;
	
	bm1.ToString(); //all zeroes
	BitMatrix<N, M> bm2(25); //should be 3 rows of bitset(25), or 10011
	BitMatrix<N, M> bm3(10); //should be 3 rows of bitset(25), or 10011
	bm2.ToString(); //prints 3 rows of 10011
	
	//set bm1 to all 1s
	bm1.Set();
	std::cout << "Set bm1 to all ones: " << std::endl;
	bm1.ToString();//print to show all ones.
	bm1.Reset(); 
	std::cout << "Set bm1 back to all zeroes: " << std::endl;
	bm1.ToString(); //print to show all zeroes again
	bm1.FlipBit(1, 1);
	bm1.FlipBit(3, 2); // this should give back an error and continue
	bm1.ToString(); //print to show all (1,1) is now showing 1, but (3,2) is not there because out of bounds.

	std::cout << "# of bits set in bm2: " << bm2.CountBits() << std::endl;

	std::cout << "bm1 at (1,1): " << bm1.at(1, 1) << std::endl;//should be 1, the bit I flipped previously

	
	BitMatrix<N, M> orBM;
	orBM = bm2.ORFunc(bm3);
	
	BitMatrix<N, M> andBM;
	andBM = bm2.ANDFunc(bm3);

	BitMatrix<N, M> xorBM;
	xorBM = bm2.XORFunc(bm3);

	std::cout << "----------bm2 matrix----------" << std::endl;
	bm2.ToString();
	std::cout << "----------bm3 matrix----------" << std::endl;
	bm3.ToString();
	std::cout << "----------OR matrix----------" << std::endl;
	orBM.ToString();
	std::cout << "----------AND matrix----------" << std::endl;
	andBM.ToString();
	std::cout << "----------XOR matrix----------" << std::endl;
	xorBM.ToString();

	return 0;
}