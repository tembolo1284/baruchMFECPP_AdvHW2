#include <system_error>
#include <iostream>
#include <fstream>
int main() {
    std::ifstream file(std::string("DOESNOTEXIST.txt"));
    try {
        file.exceptions(file.failbit | file.badbit);
        auto ec1 = std::make_error_condition(std::errc::no_such_file_or_directory);
        
        file.open("DOESNOTEXIST.txt");
    }
    catch (const std::ios_base::failure& e) {
        std::error_code ec1(e.code());
        std::error_condition ec2(5, ec1.category());

        if (e.code() == std::io_errc::stream) {
            std::cout << "The error code and what: " << e.code() << ", " << e.what() << std::endl;

            std::cout << "ec1 value, message, and category name are: " << ec1.value() << ", " << ec1.message() << ", " << ec1.category().name() << std::endl;
            std::cout << "ec2 value, message, and category name are: " << ec2.value() << ", " << ec2.message() << ", " << ec2.category().name() << std::endl;
        }
    }
    catch (...) {
        std::cout << "catch all\n";
    }
	return 0;
}