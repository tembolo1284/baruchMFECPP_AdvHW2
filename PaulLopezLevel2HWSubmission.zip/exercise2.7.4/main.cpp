
#include <system_error>
#include <iostream>
#include <ios>
#include <tuple>
#include <string>

std::tuple<std::string, int, std::string> errorFunc(std::error_code e) {
	std::tuple<std::string, int, std::string> result;
	std::get<0>(result) = e.message();
	std::get<1>(result) = e.value();
	std::get<2>(result) = e.category().name();
	return result;
}

std::tuple<std::string, int, std::string> errorFunc(std::error_condition e) {
	std::tuple<std::string, int, std::string> result;
	std::get<0>(result) = e.message();
	std::get<1>(result) = e.value();
	std::get<2>(result) = e.category().name();
	return result;
}


int main() {
	std::error_code errDefault(); //default ctor
	std::error_code errc = std::make_error_code(std::io_errc::stream);
	std::cout << "Error message, value, and category name: " << errc.message() << ", " << errc.value() << ", " << errc.category().name() << std::endl;

	std::error_code error(errc);

	//function tuple output
	std::tuple<std::string, int, std::string> tup = errorFunc(error);
	std::cout << "\nErr Message: " << std::get<0>(tup) << std::endl;
	std::cout << "Err Value: " << std::get<1>(tup) << std::endl;
	std::cout << "Err Category Name: " << std::get<2>(tup) << std::endl;

	auto err = std::make_error_condition(std::errc::no_such_file_or_directory);
	std::error_condition error3(err);
	std::cout << error3.category().name() << ", " << error3.value() << std::endl; //name of category == generic

	std::cout << "Are errors equal? " << std::boolalpha << (error == error3) << std::endl;
	std::cout << "Are errors not equal? " << std::boolalpha << (error != error3) << std::endl;

	return 0;
}