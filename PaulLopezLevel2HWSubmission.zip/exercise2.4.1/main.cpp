#include <iostream>
#include "Point.hpp"
#include <memory>
#include <vector>
using namespace PAULLOPEZ::CAD;
namespace PLC = PAULLOPEZ::CAD;

template <typename T>
using u_ptr = std::unique_ptr<T>; //making that code more readable

int main() {
	  // Block with raw pointer lifecycle
	
		//double* d = new double(1.0);
		//Point* pt = new Point(1.0, 2.0);// Two-d Point class
		std::unique_ptr<double> d = std::make_unique<double>();
		std::unique_ptr<Point> pt = std::make_unique<Point>();
		std::cout << "Point is: (";
		std::cout << pt->X() << ",";
		std::cout << pt->Y() << ")" << std::endl;
		try {
			//int a = 1;
			//a = a / 0;
			//std::vector<int> vec(3);
			//std::cout << "Accessing the 6th element of the vector...\n"; //out of range
			//std::cout << vec[5]; // 
			//throw -1;//possible exceptions to trigger.  When I uncomment any of these, I never get past this point.

		// Dereference and call member functions
			*d = 2.0;
			(*pt).X(3.0);// Modify x coordinate
			(*pt).Y(3.0);// Modify y coordinate
			std::cout << "Point is: (";
			std::cout << pt->X() << ",";
			std::cout << pt->Y() << ")" << std::endl;

			// Can use operators for pointer operations
			pt->X(4.0);// Modify x coordinate
			pt->Y(2.5);// Modify y coordinate
			std::cout << "Point is: (";
			std::cout << pt->X() << ",";
			std::cout << pt->Y() << ")" << std::endl;
			// Explicitly clean up memory (if you have not forgotten)
			//delete d;
			//delete pt;
			//std::cout << "raw pointers deleted." << std::endl;


			std::unique_ptr<double> up1(new double(10.0));
			std::unique_ptr<double> up2(new double(5.0)); //same unique pointers point to same address
			//std::unique_ptr<double> up3 (up2); //can't do this won't compile
			//up3 = up2; //can't do this. Also won't compile.

			std::unique_ptr<double> p1(new double(10.0));
			std::cout << "Address of p1: " << &p1 << std::endl;
			std::unique_ptr<double> p2 = std::move(p1); // Transfer ownership of point from p1 -> p2
			std::cout << "Address of p1: " << &p1 << std::endl; 
			std::cout << "Address of p2: " << &p2 << std::endl;

			u_ptr<double> d_ptr = std::make_unique<double>(2.0);
		}
		catch (const std::exception& e) {
			std::cout << "We have an exception."; //If we get here we never go back to main
		}


		
}