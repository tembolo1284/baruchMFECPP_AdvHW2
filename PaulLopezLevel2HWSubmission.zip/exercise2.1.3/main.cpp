#include <iostream>
#include <type_traits>
#include <memory>

class Shape {
public:
    virtual void draw() = 0;
};

class Base {
private:
    int y;
public:
    Base() {}
    void draw() {}
};

class Point: public Shape {
public:
    Point() {}
    //uncomment below two lines for exercise 4 part d)
    //Point(Point& pt) = delete;
    //Point& operator = (const Point& source) = delete;

    //below two lines for part e)
    //Point(Point&& pt);
    //Point& operator = (Point&& rhs);
    
    virtual void draw() override {}
};

int main() {
    

   std::cout << "\n\nExercise 3: \n";
   //a) Which classes / types are empty, polymorphic or abstract ?
   std::cout << std::boolalpha;
   std::cout << "\nIs Shape empty: " << std::is_empty<Shape>::value << std::endl;
   std::cout << "Is Base empty: " << std::is_empty<Base>::value << std::endl;
   std::cout << "Is Point empty: " << std::is_empty<Point>::value << std::endl;

   std::cout << "\nIs Shape abstract: " <<std::is_abstract<Shape>::value << std::endl;
   std::cout << "Is Base abstract: " << std::is_abstract<Base>::value << std::endl;
   std::cout << "Is Point abstract: " << std::is_abstract<Point>::value << std::endl;

   std::cout << "\nIs Shape polymorphic: " << std::is_polymorphic<Shape>::value << std::endl;
   std::cout << "Is Base polymorphic: " << std::is_polymorphic<Base>::value << std::endl;
   std::cout << "Is Point polymorphic: " << std::is_polymorphic<Point>::value << std::endl;


   //b) Which classes are the same ?
   std::cout << "\nAre Shape and Base the same: " << std::is_same<Shape, Base>::value << std::endl;
   std::cout << "Are Base and Shape the same: " << std::is_same<Base, Shape>::value << std::endl;
   std::cout << "Are Shape and Point the same: " << std::is_same<Shape, Point>::value << std::endl;
   std::cout << "Are Base and Point the same: " << std::is_same<Base, Point>::value << std::endl;

   //c) Which classes have a gen / spec (base / derived) relationship ?
   std::cout << "\nIs Shape base of Base: " << std::is_base_of<Shape, Base>::value << std::endl;
   std::cout << "Is Shape base of Point: " << std::is_base_of<Shape, Point>::value << std::endl;
   std::cout << "Is Base base of Shape: " << std::is_base_of<Base, Shape>::value << std::endl;
   std::cout << "Is Point base of Shape: " << std::is_base_of<Point, Shape>::value << std::endl;
   std::cout << "Is Point base of Base: " << std::is_base_of<Point, Base>::value << std::endl;


   //d) Which types can be converted to each other ?
   std::cout << "\nIs Shape convertible to Base: " << std::is_convertible<Shape, Base>::value << std::endl;
   std::cout << "Is Shape convertible to Point: " << std::is_convertible<Shape, Point>::value << std::endl;

   std::cout << "Is Base convertible to Shape: " << std::is_convertible<Base, Shape>::value << std::endl;
   std::cout << "Is Base convertible to Point: " << std::is_convertible<Base, Point>::value << std::endl;

   std::cout << "Is Point convertible to Shape: " << std::is_convertible<Point, Shape>::value << std::endl; 
   std::cout << "Is Point convertible to Base: " << std::is_convertible<Point, Base>::value << std::endl;

   

return 0;
}

