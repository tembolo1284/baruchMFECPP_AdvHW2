#include <type_traits>
#include <iostream>
#include <array>
#include <vector>
#include <complex>

template <typename T>
T Addition_impl(const T& t1, const T& t2, std::true_type) { 
    const int size = t1.size();
    T t3(t1); //copy constructor tip in forum saved me!
    for (int i = 0; i < size; i++) {
        t3[i] = t1[i] + t2[i];
    }
    return t3;
}


template <typename T>
T Addition_impl(const T& t1, const T& t2, std::false_type) {//if false it is scalar addition and we are done
    T t3 = t1 + t2;
    return t3;
}


template <typename T>
T Addition(const T& t1, const T& t2) {
    return Addition_impl(t1, t2, std::is_compound<T>());
}

template <typename T>
T Mult_impl(const T& t1, const double d, std::true_type) {
    const int size = t1.size();
    T t2(t1);
    for (int i = 0; i < size; i++) {
        t2[i] = (t1[i] * d);
    }
    return t2;
}


template <typename T>
T Mult_impl(const T& t1, const double d, std::false_type) { //if it returns false it is just a scalar and we are done
    T t2 = t1 * d;
    return t2;
}
template <typename T>
T Mult(const T& t1, const double d) {
    return Mult_impl(t1, d, std::is_compound<T>());
}

template <typename T>
void AdditiveInverse(T& val) {// val -> -val for a scalar or a vector
    val = -val;
}

int main() {

    //a) Define addition of two vectors as follows:
    //b) Define additive inverse of a vector:
    //c) Define a function for scalar multiplication of a scalar and a vector, producing a new vector. Determine the signature of this function.
    //d) Test these three functions for double, std::array<double,N>, and std::vector<double>.
    double num = 2.0;
    double test = 5.5;
    const int N = 5;
    
    std::vector<double> vec{ 2.5,3.5,4.5,5.5 };
    double addResult = Addition(num, test); // should give 7.5
    std::cout << "Basic addition: " << addResult << std::endl;
    
    AdditiveInverse(num);
    std::cout << "Additive Inverse: " << num; // should output -2
    
    std::vector<double> vecResult = Mult(vec, num); //should give -5, -7, -9, -11
    std::cout << "\nScalar Mult for vector: "; 
    for (int i = 0; i < vecResult.size(); i++) {
        std::cout << vecResult[i]<< " ";
    }

    std::cout << "\nAdding two vectors: ";
    std::vector<double> vecSumResult = Addition(vec, vecResult);//should give -2.5, -3.5, -4.5, -5.5
    for (int i = 0; i < vecSumResult.size(); i++) {
        std::cout << vecSumResult[i] << " ";
    }

    std::cout << "\nScalar Mult for array: ";
    std::array<double,N> arr{1.0, 2.0, 3.0, 4.0, 5.0};
    std::array<double,N> arrResult = Mult(arr, num); //should give -2, -4, -6, -8, -10
    for (int i = 0; i < arrResult.size(); i++) {
        std::cout << arrResult[i] << " ";
    }

    
    std::cout << "\nAdding two arrays: ";
    std::array<double,N> arrSumResult = Addition(arr, arrResult);//should give -1, -2, -3, -4, -5
    for (int i = 0; i < arrSumResult.size(); i++) {
        std::cout << arrSumResult[i] << " ";
   }


    //e) Test the functions on containers whose underlying type is std::complex<double>.
    std::complex<double> c1{ 1.0,2.0 }; //1 + 2i
    std::complex<double> c2{ -1.0,-3.5 };//-1 - 3.5i
    std::complex<double> c3{ -3.0,-0.5 };//-3 - 0.5i
    std::complex<double> c4{ -1.0,2.5 };//-1 + 2.5i
    
    const int M = 4;
    std::vector<std::complex<double>> cxVec;
    std::array<std::complex<double>,M> cxArr;

    cxVec.push_back(c1);
    cxVec.push_back(c2);
    cxVec.push_back(c3);
    cxVec.push_back(c4);
    for (int i = 0; i < 4; i++) {
        cxArr[i] = cxVec[i];
    }
    double cNum = 3.0;

    std::vector<std::complex<double>> cxVecResult = Mult(cxVec, cNum); // should give; (3,6), (-3,-10.5), (-9,-1.5), (-3,7.5)
    std::cout << "\nScalar Mult for complex vector: ";
    for (int i = 0; i < cxVecResult.size(); i++) {
        std::cout << cxVecResult[i] << " ";
    }

    std::cout << "\nAdding two complex vectors: ";
    std::vector<std::complex<double>> cxVecSumResult = Addition(cxVec, cxVecResult);
    for (int i = 0; i < cxVecSumResult.size(); i++) {
        std::cout << cxVecSumResult[i] << " ";
    }


    std::cout << "\nScalar Mult for complex array: ";
    std::array<std::complex<double>, M> cxArrResult = Mult(cxArr, cNum);  
    for (int i = 0; i < cxArrResult.size(); i++) {
        std::cout << cxArrResult[i] << " ";
    }


    std::cout << "\nAdding two complex arrays: ";
    std::array<std::complex<double>, M> cxArrSumResult = Addition(cxArr, cxArrResult);
    for (int i = 0; i < cxArrSumResult.size(); i++) {
        std::cout << cxArrSumResult[i] << " ";
    }

    return 0;

}