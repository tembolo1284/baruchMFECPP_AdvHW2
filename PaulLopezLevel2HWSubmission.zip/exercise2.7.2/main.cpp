
#include <system_error>
#include <iostream>
#include <tuple>
#include<string>
#include <boost/system/error_code.hpp>

std::tuple<std::string,int,std::string> errorFunc(std::error_condition err) {
	std::tuple<std::string, int, std::string> result;
	std::get<0>(result) = err.message();
	std::get<1>(result) = err.value();
	std::get<2>(result) = err.category().name();
	return result;
}

int main() {
	auto err = std::make_error_condition(std::errc::no_such_file_or_directory);
	std::cout << "Error message: " << err.message() << std::endl;

	std::error_condition error0(); //default ctor
	//std::cout << "Default ctor error: " << error0 << std::endl;

	std::error_condition error1(err);
	std::cout << "Error value: " << error1.value() << std::endl; //gives me value of 2

	std::error_condition error2(5,std::generic_category());
	std::cout << "Error value and category: " << error2.value() << ", "<<error2.category().name() << std::endl; //for value 5 and generic_category()

	std::error_condition error3(err);
	std::cout << error3.category().name() << std::endl; //name of category
	


	//function tuple output
	std::cout << "----------Tuple output----------"  << std::endl;
	std::tuple<std::string,int,std::string> tup = errorFunc(error3);
	std::cout << "\nErr Message: " << get<0>(tup) << std::endl;
	std::cout << "Err Value: " << get<1>(tup) << std::endl;
	std::cout << "Err Category Name: " << get<2>(tup) << std::endl;
	return 0;
}