#include <iostream>

template <typename T>
T epsilonCalc(T t) {
	T epsilon = 1;

	while (1.0 + (0.5 * epsilon) != 1.0) {
		epsilon *= 0.5; //seems like i'll be in trouble for int type!
	}
	return epsilon;
}


int main() {
	double epsilon = 1.0;
	while ((1.0 + 0.5 * epsilon) != 1.0) {
		epsilon *= 0.5;
	}
	std::cout << "Epsilon value: " << epsilon <<std::endl; //2.22045e-16
	std::cout << std::numeric_limits<double>::epsilon() << std::endl; //2.22045e-16 same value as above I like it!

	long a = 1.0;
	short b = 1.0;
	float c = 1.0;

	std::cout << "Epsilon value for int type: " << epsilonCalc(1) << std::endl;//int test //epsilon is 0....so sad...
	std::cout << std::numeric_limits<int>::epsilon() << std::endl; //2.22045e-16 same value as above I like it!

	std::cout << "\nEpsilon value for long type: " << epsilonCalc(a) << std::endl; //0  for long test
	std::cout << std::numeric_limits<long>::epsilon() << std::endl; //gives me 0

	std::cout << "\nEpsilon value for short type: " << epsilonCalc(b) << std::endl; //0  for short test
	std::cout << std::numeric_limits<short>::epsilon() << std::endl; //gives me 0

	std::cout << "\nEpsilon value for float type: " << epsilonCalc(c) << std::endl; //2.22045e-16  for float test
	std::cout << std::numeric_limits<float>::epsilon() << std::endl; //gives me 1.19209e-07

	return 0;
}