#include <iostream>
#include <functional>
#include <vector>
#include <algorithm>

template <typename R, typename D>
using FunctionType = std::function<R(const D x)>;
// Working function type
using ScalarFunction = FunctionType<double, double>;

template <typename R, typename D>
using ArrayType = std::function<R(const D x, const D y)>;
// Working function type
using ArrayFunction = ArrayType<double, double>;

template <typename T>
std::function<T(const T&)> bind1st (const std::function<T(const T& x, const T& y)>& f, const T& x_) {
    // Bind to the first param x of f(x,y)
    return [=](const T& other) {
        return f(x_, other);
    };
}
template <typename T>
std::function<T(const T&)> bind2nd (const std::function<T(const T& x, const T& y)>& f, const T& y_) {
    return [=](const T& other) {
        return f(other, y_);
    };
}

int main() {
    double yval = 10.0;

    ArrayFunction fxy = [=](auto x,auto y) {return x + y; };//had to create a new function type to accept 2 variables as input(domain) R^2 -> R.
    ScalarFunction fx = bind2nd<double>(fxy, yval); 
    std::cout << fx(3.0) << std::endl; // should be 10 bonded + 3 = 13
    // Test new bind code on STL algorithms
    std::vector<double> vec(5, 2.0); //vector of 5 2's
    std::transform(vec.begin(), vec.end(), vec.begin(), fx); //transform each guy by fx --> 2 + 10 = vector of 12's.  Elegant stuff!
    for (auto i = 0; i < vec.size(); ++i)
    {
        std::cout << vec[i] << ",";
    }

}