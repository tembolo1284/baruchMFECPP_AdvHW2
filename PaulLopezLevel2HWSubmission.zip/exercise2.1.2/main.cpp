#include <iostream>
#include <type_traits>
#include <memory>

template <typename T>
void IsPointerNew(const T& t, std::true_type) {
    std::cout << *t << "\n"; //we have a pointer and deref it to print it
}

template <typename T>
void IsPointerNew(const T& t, std::false_type) {
    if (std::is_scalar<T>::value) {
        std::cout << t << "\n"; //We don't have a pointer, but confirm it is a scalar type first before printing it
    }
}

template <typename T>
void bridgeFn(const T& t) {
    IsPointerNew(t, std::is_pointer<T>()); //first piece of bridge so we can compile successfully
}


int main() {

   //Exercise 2:
   //We create a template function that supports both pointers and reference types. If it is a pointer it is dereferenced and 
   //then printed while if it is not a pointer type and it is a scalar reference type then it is printed directly. Use the is_pointer() 
   //function in conjunction with std::true_type and std::false_type to determine which implementation should be called.
   std::cout << "\n\nExercise 2: \n";
   double* p1 = new double (3.14);
   bridgeFn(p1); //print pointer
   int n = 5;
   bridgeFn(n); //prints scalar

return 0;
}

