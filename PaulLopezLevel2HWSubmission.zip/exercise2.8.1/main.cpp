/*d) Set the bits in a bitset in different ways:
Set/reset all bits.
Flip the bits.
Test if none, all or any bits are set.
Access the elements.
Count the number of set bits.
e) Convert a bitset to std::string, unsigned long and unsigned long long.
f) Test if two bitsets are equal or unequal.*/
#include <bitset>
#include <boost/dynamic_bitset.hpp>
#include <iostream>

int main() {
	const int N = 5;
	boost::dynamic_bitset<unsigned long> dbs1(N);
	boost::dynamic_bitset<unsigned long long> dbs2(N);
	int index = 3;
	int numBits = 5;
	std::bitset<N> bs1;
	std::cout << "bs1: " << bs1 << std::endl; //5 zeroes

	std::bitset<N> bs2(std::string("01110"));
	std::bitset<N> bs3(std::string("11101110"),index,numBits);
	std::cout << "bs2: " << bs2 << ", bs3: " << bs3 << std::endl; //both will show 01110

	std::cout << std::boolalpha << "Are bs2 and bs3 equal?" << (bs2 == bs3) << std::endl; //evaluates to true
	std::cout << "Are bs1 and bs3 equal?" << (bs1 == bs3) << std::endl; //evaluates to false

	std::bitset<N> bs4; // we start with zeroes
	std::cout <<"\nWe start with zeroes: " << bs4 << std::endl;
	bs4.set(); //set everything to 1
	std::cout << "We now have all ones: " << bs4 << std::endl;
	bs4.reset(); //set everything to 0
	std::cout << "We now have all zeroes again: " << bs4 << std::endl;
	bs4.flip(0); //flip index number 0
	bs4.flip(2); //flip index number 2
	std::cout << "We now have a 1 in index 2: " << bs4 << std::endl; //00101

	int countBit{};
	for (int i = 0; i < N; i++) {
		countBit += bs4[i];
	}
	std::cout << "Number of set bits in bs4: " << countBit << std::endl;


	std::bitset<N> bsTweak(25);
	std::cout << "\nconvert to string: " << bsTweak.to_string() << std::endl;
	std::cout << "convert to ulong: " << bsTweak.to_ulong() << std::endl;
	std::cout << "convert to ulong long: " << bsTweak.to_ullong() << std::endl << std::endl;

	try {
	//std::bitset<N> bs4(std::string("011W0")); //invalid arguments gives me invalid bitset char error below
	std::bitset<N> bs5(std::string("11101110"), 20, numBits); //out of range gives me invalid bitset position
	}
	catch(std::exception& e) {
		std::cout << "Error is: " << e.what() << std::endl;
	}


	return 0;
}