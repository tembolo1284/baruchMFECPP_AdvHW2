#include <iostream>
#include <string>
#include <string.h>
#include <fstream>
#include <system_error>
#include <boost/system/error_code.hpp>

boost::system::error_condition read(std::string myFile) {
	std::ifstream in(myFile.c_str());
	if (in.is_open() == false) {
		return boost::system::errc::make_error_condition(boost::system::errc::no_such_file_or_directory);
	}
	std::cout << in.rdbuf() << std::endl; //print file content
	in.close(); //close file
	return boost::system::error_condition();
}

int main() {

	//boost version part
	std::string file1 = "file.txt";
	std::string file2 = "testFile.txt";
	std::cout <<"File1 read results: " << read(file1) << std::endl;
	std::cout <<"\nFile2 read results: " << read(file2) << std::endl;
	
	
	auto err = std::make_error_condition(std::errc::no_such_file_or_directory);

		std::string str;
		//Creating a file with name testFile.txt, if it doesn't already exist
		//std::ifstream myFile("file.txt"); //file is NOT there
		std::ifstream myFile("testFile.txt"); //file is there
		std::cout << "-------------------------"<<std::endl;

		//Check file opening condition
		if (myFile.is_open()) {
			//get all text line by line
			while (getline(myFile, str)) {
				//Printing contents
				std::cout << str << std::endl;
			}
			//closing opened file
			myFile.close();
			std::cout << "\nFile was successfully closed." << std::endl;
		}
		else {
			std::cout << "\nFile is not there!" << std::endl;
			std::cout << err.message() << std::endl;
		}
}