#include <iostream>
#include <fstream>
#include <stdio.h>
#include <cstdio>
#include <functional>
#include "Point.hpp"

using namespace PAULLOPEZ::CAD;
namespace PLC = PAULLOPEZ::CAD;
using SmartFile = std::shared_ptr<FILE>;


class Deleter {
public:
	std::FILE* file{nullptr};
	Deleter() {};
	Deleter(std::shared_ptr<FILE> myfile) {}
	~Deleter() {
		fclose(file);
		std::cout << "File Closer destructor.";
	}

	// Deleter operator () { 
	//	fclose(file);
	//	std::cout << "File was successfully closed." << std::endl;
	//}


};
void funcCloser(std::FILE* file) {
	if (file == NULL) {
		std::cout << "Opening of file failed.";
	}
	else {
		fclose(file); //closing open file
		std::cout << "Bye file! This is the function call." << std::endl;
	}
} 

int main() {
	

	//try starts here
	try {
		auto deleter = [](Point* pt)-> void {
			std::cout << "Bye:" << *pt;
		};
		std::FILE* myFile{nullptr};
		fopen_s(&myFile, "myFile.txt", "w");
		fputs("Adding short text to test file.", myFile);

		auto fileFinalizer = [](std::FILE* myFile)-> void {
			if (myFile == NULL) {
				std::cout << "File went out of scope looks like.";
			}
			else {
				fclose(myFile); //closing open file
				std::cout << "Bye file! This is from the lambda function." << std::endl;
			}
		};
	
		using SmartPoint = std::shared_ptr<Point>;
		SmartPoint p1(new Point(1,2), deleter);
		
		Deleter file();
		using FileFinalizer = std::function<void(FILE*)>;
		FileFinalizer f1 = funcCloser;
	
		//SmartFile newFile(myFile, fileFinalizer); //using lambda
		SmartFile newFile(myFile, funcCloser); //using free function
		//SmartFile newFile(myFile, f1); //using function object
		

		std::cout << "Is the file open? ";
		if (myFile == NULL) {
			std::cout << "Opening of file failed.";
			throw -1;
		}
		else {
			std::cout << "File is open but we'll throw anyway." << endl;
			//throw -1;
		}
		//throw - 1;

		for (int i = 0; i < 5; i++) {
			if (i == 3) {
				throw -1;
			}
			fputs(" This is a line of text", myFile);
		}

	}
			catch (const int error) { 
				std::cout << "\nWe are in the catch!" << std::endl;
				//fopen_s(&myFile, "myFile.txt", "r"); //I can't open the file again...red squiggle is under myFile.
				//std::cout << "File has been opened again!" << std::endl;

				//I'm not able to successfully open the file again.  It's out of scope from what I see.
			}
}