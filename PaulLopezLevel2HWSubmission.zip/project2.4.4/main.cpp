#include <iostream>
#include <memory>
#include <list>
// Base class
class Base {
private:
public:
    Base() { }
    virtual void print() const = 0;
//protected:
    virtual ~Base() { std::cout << "Base destructor\n\n"; }
};

// Derived class
class Derived : public Base {
private:
public:
    Derived() : Base() { }
    ~Derived() { std::cout << "Derived destructor\n"; }
    void print() const { std::cout << "derived object\n"; }
};

Derived FactoryDerived() {
    Derived derived;
    return derived;
}

int main() {
    //std::list<Base> listBase; this doesn't compile for me
    std::list<Derived> listDerived; //this compiles fine

    //std::shared_ptr<Base> pt1;// compiles for me
    //std::unique_ptr<Base> pt2;// doesn't compile for me. I get message: error C2248: 'Base::~Base': cannot access protected member declared in class 'Base'
    //When I comment out protected and make the destructor public, then the unique ptr line of code above compiles.

    //std::shared_ptr<Base> pt3;
    //std::unique_ptr<Base> pt4;

    //std::shared_ptr<Base> pt5;
    //std::unique_ptr<Base> pt6;
    

   //(*pt1).print(); //doesn't compile
   //(*pt2).print(); //also doesn't compile
   // 
    //derived factory
    Derived d1 = FactoryDerived(); //create derived instances
    Derived d2 = FactoryDerived();
    Derived d3 = FactoryDerived();//3 instances here to destroy

    listDerived.push_back(d1); //push it into back of list
    listDerived.push_back(d2);
    listDerived.push_back(d3); //3 copies made to push into list

    for (auto elem : listDerived) {
        elem.print(); //print function to show we have a derived object
    }
    //we should have a total of 6*2 = 12 destructors called for base and derived

    return 0;
}