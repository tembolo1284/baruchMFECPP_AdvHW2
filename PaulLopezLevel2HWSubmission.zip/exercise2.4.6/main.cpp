#include <iostream>
#include <memory>

int main() {
	//a) Create a shared pointer, print the use count and then create a weak pointer that observes it. Print the use count again. What are the values ?
	std::shared_ptr<int> ptr = std::make_shared<int>(5);
	std::cout << "ptr count: " << ptr.use_count() << std::endl; // 1
	std::weak_ptr<int> weak1 = ptr;
	if (auto i = weak1.lock()) {
		std::cout << *i << std::endl; //prints out 5, or value of shared pointer.
	}
	std::cout << "ptr count: " << ptr.use_count() << std::endl; // 1
	std::cout << "weak1 count: " << weak1.use_count() << std::endl; //1

	//b) Assign a weak pointer to a shared pointer and check that the weak pointer is not empty.
	std::shared_ptr<int> ptr2(weak1);
	std::cout << "weak1 count: " << weak1.use_count() << std::endl; //count == 2
	
	
	//c) Assign a weak pointer to another weak pointer; assign a weak pointer to shared pointer.  What is the use count in both cases ?
	std::shared_ptr<int> ptr3(weak1); 
	std::cout << "weak1 count is now: " << weak1.use_count() << std::endl; // count == 3

	std::weak_ptr<int> weak2 = weak1;
	std::cout << "weak1 count: " << weak1.use_count() << std::endl; // count == 3


	return 0;
}