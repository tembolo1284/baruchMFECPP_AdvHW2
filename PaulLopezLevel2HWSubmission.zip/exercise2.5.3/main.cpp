#include <iostream>
#include <boost/math/special_functions/next.hpp>


int main() {
	// Number gaps/bits/ULP between
// 2 floating-point values a and b
// Returns a signed value indicating whether a < b
	//float_distance
	double a = 0.1; 
	double b = a + std::numeric_limits<double>::min();
	std::cout << boost::math::float_distance(a, b) << std::endl; // returns 0
	a = 1.0; b = 0.0;
	std::cout << boost::math::float_distance(a, b) << std::endl; // returns -4.60718e+18

	//float_next, nextafter
	std::cout << "float_next " << boost::math::float_next(a) << std::endl;

	//float_prior
	std::cout << "float_prior " << boost::math::float_prior(a) << std::endl; //a = 1.0

	//float_advance
	std::cout << "float_advance: " << boost::math::float_advance(a, 1.00001) << std::endl;
	
	//boost::nextafter(x,y)
	std::cout << "nextafter(1,0) " << boost::math::nextafter(a, b) << std::endl;
	std::cout << "nextafter(0,1) " << boost::math::nextafter(b, a) << std::endl;

	return 0;

	


}