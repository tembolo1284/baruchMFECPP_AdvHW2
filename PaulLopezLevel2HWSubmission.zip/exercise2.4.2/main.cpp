#include <iostream>
#include <memory>
#include "Point.hpp"

using namespace PAULLOPEZ::CAD;
namespace PLC = PAULLOPEZ::CAD;


class C1 {
private:
    //double* d; OLD WAY
    std::shared_ptr<double> d;
    std::shared_ptr<Point> p;
public:
    C1(std::shared_ptr<double> value, std::shared_ptr<Point> pt) : d(value), p(pt) {}
    virtual ~C1() { 
        std::cout << "\nC1 destructor\n"; }

    void print() const { 
        std::cout << "Value of d and p: " << *d << " " << std::endl;
        (*p).Print();
    }
};

class C2
{
private:
    //double* d; OLD WAY
    std::shared_ptr<double> d;
    std::shared_ptr<Point> p;
public:
    C2(std::shared_ptr<double> value, std::shared_ptr<Point> pt) : d(value), p(pt) {}
    virtual ~C2() { 
        std::cout << "\nC2 destructor\n"; 
    }
    void print() const { 
        std::cout << "Value of d and p: " << *d << " " << std::endl;
        (*p).Print();
    }
};



int main() {
    std::shared_ptr<double> d;
    std::shared_ptr<Point> p; //for part c below
    {
        d = std::make_shared<double>(5.0);
        p = std::make_shared<Point>(1, 1);
        std::cout << "d count == " << d.use_count() << std::endl;//should give 1
        {//scoping out the d shared ptr 
            C1 c1{ d,p };
            c1.print();
            std::cout << "d count == " << d.use_count() << std::endl; //should give 2
            C2 c2{ d,p };
            c2.print();
            std::cout << "d count == " << d.use_count() << std::endl; //should give 3
        }
        std::cout << "d count == " << d.use_count() << std::endl; //should give 1
    }

    //part c
    
    {
        d = std::make_shared<double>(7.5);
        p = std::make_shared<Point>(2,5);
        std::cout << "p count == " << p.use_count() << std::endl;//should give 1
        {//scoping out the point p shared ptr 
            C1 c1{ d,p };
            c1.print();
            std::cout << "p count == " << p.use_count() << std::endl; //should give 2
            C2 c2{ d,p };
            c2.print();
            std::cout << "p count == " << p.use_count() << std::endl; //should give 3
        }
        std::cout << "p count == " << p.use_count() << std::endl; //should give 1
    }

    //part d
    std::shared_ptr<int> sp1 = std::make_shared<int>(8);
    std::cout << "\nsp1 count == " << sp1.use_count() << std::endl; //should give 1
    std::shared_ptr<int> sp2 = std::move(sp1); //giving up ownership to sp2. Reminds me of Rust a bit sorta maybe.
    std::cout << "sp1 count == " << sp1.use_count() << std::endl; //should give 0 now
    std::cout << "sp2 count == " << sp2.use_count() << std::endl; //should give 1
    sp2.reset();
    std::cout << "sp2 count == " << sp2.use_count() << std::endl; //should give 0 after cleaning it up in reset() above.
    
    std::shared_ptr<int> sp3 = std::make_shared<int>(8); 
    std::shared_ptr<int> sp4 = sp3; //assignment
    std::shared_ptr<int> sp5(sp3); //copy of sp3 for sp5
    std::shared_ptr<int> sp6 = std::make_shared<int>(15);
    std::cout << "sp3: " << *sp3 << ", sp4: " << *sp4 << ", sp5: " << *sp5 << std::endl << std::endl; //printing them all out to prove copy and assignment worked
    std::cout << "Before Swap --------------------" << std::endl;
    std::cout << "sp4: " << *sp4 << ", sp6: " << *sp6 << std::endl;
    std::swap(sp4, sp6);
    std::cout << "After Swap --------------------" << std::endl;
    std::cout << "sp4: " << *sp4 << ", sp6: " << *sp6 << std::endl;
    
}